<?
$platform = "win";
include 'download_beta.php';
?>
