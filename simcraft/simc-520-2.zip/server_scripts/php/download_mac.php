<?
$platform = "mac";
include 'download.php';
?>
