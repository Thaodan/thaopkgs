<?
$platform = "mac";
include 'download_beta.php';
?>
