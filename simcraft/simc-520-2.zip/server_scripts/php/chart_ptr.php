<?
$patch = trim(file_get_contents('PTRFOLDER'));
include 'chart.php';
?>
