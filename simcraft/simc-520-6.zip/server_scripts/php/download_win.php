<?
$platform = "win";
include 'download.php';
?>
